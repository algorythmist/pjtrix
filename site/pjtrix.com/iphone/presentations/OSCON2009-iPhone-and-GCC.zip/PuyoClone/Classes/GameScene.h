//
//  GameScene.h
//  PuyoClone
//
//  Created by PJ Cabrera on 5/8/09.
//  Copyright 2009 PJ Cabrera. All rights reserved.
//

#import "cocos2d.h"

@interface GameScene : Scene {
	
}

@end
