//
//  PuyoCloneAppDelegate.h
//  PuyoClone
//
//  Created by PJ Cabrera on 5/8/09.
//  Copyright 2009 PJ Cabrera. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "cocos2d.h"

@interface PuyoCloneAppDelegate : NSObject <UIAlertViewDelegate, 
	UIApplicationDelegate>
{
	UIWindow *window;
}

@end
