//
//  HelloWorldApp.h
//  HelloWorld
//
//  Created by PJ Cabrera on 08/18/2008.
//  Copyright PJ Cabrera 2008. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "HelloWorldApp.h"

int main(int argc, char *argv[]) {

        UIApplicationMain(argc, argv, @"HelloWorldApp", @"HelloWorldApp");
        return 0;
}